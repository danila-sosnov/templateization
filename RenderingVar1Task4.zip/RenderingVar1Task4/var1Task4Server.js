const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = 3000;

function getRandomImage(images)
{
    return images[Math.floor(Math.random() * images.length)];
}

function renderTemplate(template,data)
{
    let output = template;
    for(key in data)
    {
        const marker = `{{${key}}}`;
        output = output.replaceAll(marker,String(data[key]));
    }

    return output;
}

const images = 
[   
       '/images/bear.png',     
       '/images/bird.png',     
        '/images/cow.png',     
      '/images/crab.png',    
       '/images/frog.png',
     '/images/elephant.png',
     '/images/tucan.png',
     '/images/racoon.png',
     '/images/gorilla.png',
     '/images/dog.png',
    
]

const animals = 
[
    {
        name: 'Bear',
        
    },
    {
        name: 'Bird',
      
    },
    {
        name: 'Cow',

    },
    {
        name: 'ELephant',
     
    },
    {
        name: 'Frog',
     
    },
    {
        name: 'Crab',
     
    },
    {
      name: 'Tucan',
   
    },
    {
    name: 'Racoon',

    },
    {
      name: 'Gorilla',
      
      },
      {
        name: 'Dog',
        
        },
]

const server = http.createServer(function(request,response)
{
    console.log("Получен запрос: ", request.method, request.url);

    switch(request.url)
    {
        case "/":
            {
                   const filePath =path.join(__dirname,'public','templates','index.html');
                   const filePathCard = path.join(__dirname,'public','templates','card.html');
                try{
                    const htmlTemplate = fs.readFileSync(filePath,'utf-8');
                    const card = fs.readFileSync(filePathCard,'utf-8');
                     const cardsHtml = animals.map(animal => renderTemplate(card,
                         {
                             ...animal,
                             imageUrl: getRandomImage(images),
                         }
                         )).join("");
                    const html = renderTemplate(htmlTemplate,{cardsHtml});
                    response.writeHead(200,{"Content-Type": "text/html; charset=utf-8",});
                    response.end(html);
                }
                catch(error)
                {
                    console.log(error.message);
                    response.writeHead(500,{"Content-Type": "text/plain; charset=utf-8",})
                    response.end("Не удалось прочитать index.html");
                }
            }
            break;

            case "/css/style.css":
                {
                  const filePath = path.join(__dirname,'public', 'css', 'style.css');
                  try{
                    const css = fs.readFileSync(filePath,'utf-8');
                    response.writeHead(200,{"Content-Type": "text/css; charset=utf-8",});
                    response.end(css);
                  }
                  catch(error){
                    console.log(error.message);
                    response.writeHead(500,{"Content-Type": "text/plain; charset=utf-8",});
                    response.end("Не удалось прочитать style.css");
                  }       
                }
                break;

                case "/images/bear.png":
                {
                  const filePath = path.join(__dirname,'public', 'images', 'bear.png');
                  try{
                    const bear = fs.readFileSync(filePath);
                    response.writeHead(200,{"Content-Type": "image/png",});
                    response.end(bear);
                  }
                  catch(error){
                    console.log(error.message);
                    response.writeHead(500,{"Content-Type": "image/png",});
                    response.end("Не удалось прочитать bear.png");
                  }       
                }
                break;

                case "/images/bird.png":
                {
                  const filePath = path.join(__dirname,'public', 'images', 'bird.png');
                  try{
                    const bird = fs.readFileSync(filePath);
                    response.writeHead(200,{"Content-Type": "image/png",});
                    response.end(bird);
                  }
                  catch(error){
                    console.log(error.message);
                    response.writeHead(500,{"Content-Type":"text/plain; charset=utf-8",});
                    response.end("Не удалось прочитать bird.png");
                  }       
                }
                break;

                case "/images/cow.png":
                    {
                      const filePath = path.join(__dirname,'public', 'images', 'cow.png');
                      try{
                        const cow = fs.readFileSync(filePath);
                        response.writeHead(200,{"Content-Type": "image/png",});
                        response.end(cow);
                      }
                      catch(error){
                        console.log(error.message);
                        response.writeHead(500,{"Content-Type":"text/plain; charset=utf-8",});
                        response.end("Не удалось прочитать cow.png");
                      }       
                    }
                    break;

                    case "/images/crab.png":
                    {
                      const filePath = path.join(__dirname,'public', 'images', 'crab.png');
                      try{
                        const crab = fs.readFileSync(filePath);
                        response.writeHead(200,{"Content-Type": "image/png",});
                        response.end(crab);
                      }
                      catch(error){
                        console.log(error.message);
                        response.writeHead(500,{"Content-Type":"text/plain; charset=utf-8",});
                        response.end("Не удалось прочитать crab.png");
                      }       
                    }
                    break;

                    case "/images/elephant.png":
                        {
                          const filePath = path.join(__dirname,'public', 'images', 'elephant.png');
                          try{
                            const elephant = fs.readFileSync(filePath);
                            response.writeHead(200,{"Content-Type": "image/png",});
                            response.end(elephant);
                          }
                          catch(error){
                            console.log(error.message);
                            response.writeHead(500,{"Content-Type":"text/plain; charset=utf-8",});
                            response.end("Не удалось прочитать elephant.png");
                          }       
                        }
                        break;

                    case "/images/frog.png":
                            {
                              const filePath = path.join(__dirname,'public', 'images', 'frog.png');
                              try{
                                const frog = fs.readFileSync(filePath);
                                response.writeHead(200,{"Content-Type": "image/png",});
                                response.end(frog);
                              }
                              catch(error){
                                console.log(error.message);
                                response.writeHead(500,{"Content-Type":"text/plain; charset=utf-8",});
                                response.end("Не удалось прочитать frog.png");
                              }       
                            }
                            break;
                    case "/images/tucan.png":
                              {
                                const filePath = path.join(__dirname,'public', 'images', 'tucan.png');
                                try{
                                  const tucan = fs.readFileSync(filePath);
                                  response.writeHead(200,{"Content-Type": "image/png",});
                                  response.end(tucan);
                                }
                                catch(error){
                                  console.log(error.message);
                                  response.writeHead(500,{"Content-Type":"text/plain; charset=utf-8",});
                                  response.end("Не удалось прочитать tucan.png");
                                }       
                              }
                              break;

                    case "/images/racoon.png":
                                {
                                  const filePath = path.join(__dirname,'public', 'images', 'racoon.png');
                                  try{
                                    const racoon = fs.readFileSync(filePath);
                                    response.writeHead(200,{"Content-Type": "image/png",});
                                    response.end(racoon);
                                  }
                                  catch(error){
                                    console.log(error.message);
                                    response.writeHead(500,{"Content-Type":"text/plain; charset=utf-8",});
                                    response.end("Не удалось прочитать racoon.png");
                                  }       
                                }
                                break;
                      case "/images/gorilla.png":
                                  {
                                    const filePath = path.join(__dirname,'public', 'images', 'gorilla.png');
                                    try{
                                      const gorilla = fs.readFileSync(filePath);
                                      response.writeHead(200,{"Content-Type": "image/png",});
                                      response.end(gorilla);
                                    }
                                    catch(error){
                                      console.log(error.message);
                                      response.writeHead(500,{"Content-Type":"text/plain; charset=utf-8",});
                                      response.end("Не удалось прочитать gorilla.png");
                                    }       
                                  }
                                  break;
                        case "/images/dog.png":
                                    {
                                      const filePath = path.join(__dirname,'public', 'images', 'dog.png');
                                      try{
                                        const dog = fs.readFileSync(filePath);
                                        response.writeHead(200,{"Content-Type": "image/png",});
                                        response.end(dog);
                                      }
                                      catch(error){
                                        console.log(error.message);
                                        response.writeHead(500,{"Content-Type":"text/plain; charset=utf-8",});
                                        response.end("Не удалось прочитать dog.png");
                                      }       
                                    }
                                    break;
      
    


                default:
                     const filePath = path.join(__dirname,'public','404.html');
                 try{
                      const html404 = fs.readFileSync(filePath,'utf-8');
                      response.writeHead(404,{"Content-Type":"text/html; charset=utf-8",});
                      response.end(html404);
                     }
                 catch(error)
                     {
                         console.log(error.message);
                          response.writeHead(500,{"Content-Type":"text/plain; charset=utf-8",});
                          response.end("Не удалось прочитать 404.html");
                      }
          }
});

server.listen(PORT,function()
{
    console.log("Сервер запущен: http://localhost:" + PORT);
});